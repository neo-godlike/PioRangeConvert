#include <QtWidgets>

#include <map>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <ctime>

#include <queue>

using namespace std;

#define _CRT_SECURE_NO_WARNINGS

string parse_file(string filename);




